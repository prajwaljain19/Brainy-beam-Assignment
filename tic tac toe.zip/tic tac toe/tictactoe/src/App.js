import "./App.css";
import React from "react";
import Hotspot from "./components/hotspot";

function App() {
  return (
    <div className="App">
      <div className='bg font-bold'>Tic Tac Toe</div>
      <Hotspot />  {}
    </div>
  );
}


export default App;
