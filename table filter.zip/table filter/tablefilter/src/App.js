import './App.css';
import Browse from './component/Browse';

function App() {
  return (
   <div>
    <Browse />
   </div>
  );
}

export default App;
