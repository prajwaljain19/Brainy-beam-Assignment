export const API_KEY = 
"https://jsonplaceholder.typicode.com/users";